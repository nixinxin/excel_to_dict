from setuptools import setup, find_packages

# read the contents of your README file
from os import path
this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

requires = [
    "pandas >= 0.23.4",
    "xlrd >= 0.9.0",
]

setup(
    name="excel_to_dict",
    version="1.1.0",
    author="nixinxin",
    author_email="1025464043@qq.com",
    description="A small package to convert records in excel into dict",
    long_description=long_description,
    long_description_content_type='text/markdown',
)
