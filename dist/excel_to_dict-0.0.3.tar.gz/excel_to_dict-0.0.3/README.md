A small package to convert records in excel into dict.
